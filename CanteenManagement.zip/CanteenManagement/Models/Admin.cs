﻿namespace CanteenManagement.Models
{
    public class Admin
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public long Contact { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
