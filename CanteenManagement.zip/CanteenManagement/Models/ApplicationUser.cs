﻿using Microsoft.AspNetCore.Identity;

namespace CanteenManagement.Models
{
    public class ApplicationUser: IdentityUser
    {
    }
}
