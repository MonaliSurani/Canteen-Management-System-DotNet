﻿namespace CanteenManagement.ViewModels
{
    public static class UserRole
    {
        public const string Admin = "Admin";
        public const string Employee = "Employee";
        public const string Owner = "Owner";
    }
}
