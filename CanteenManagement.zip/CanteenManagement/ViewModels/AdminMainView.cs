﻿namespace CanteenManagement.ViewModels
{
    public class AdminMainView
    {
        public List<UsersList> usersList { get; set; }

        public Register register { get; set; }
    }
}
