﻿using CanteenManagement.Models;

namespace CanteenManagement.ViewModels
{
    // Product.cs
    //public class Product
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //    public decimal Price { get; set; }
    //}

    //// CartItem.cs
    //public class CartItem
    //{
    //    public Item Product { get; set; }
    //    public int Quantity { get; set; }
    //}

    //// Cart.cs
    //public class Cart
    //{
    //    public List<CartItem> Items { get; set; } = new List<CartItem>();

    //    public decimal Total
    //    {
    //        get { return Items.Sum(item => item.Product.Price * item.Quantity); }
    //    }
    //}


}
